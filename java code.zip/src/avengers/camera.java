package avengers;

import java.util.*;

public class camera extends Thread{

    public camera() {
    }

    public String video;
    public int heartRate;
    public String picture;
    private long time;
    public void run(){
    	
    }
    static void storeVideo() {
    	
    }
    private static void removeVideo() {

    }

    public static String getVideo() {
        return "";
    }

    static void takePicture() {

    }

    public static String getPicture() {
        return "";
    }

}