package avengers;

import java.util.*;

public class watch extends Thread{
    public watch() {}
    static int heartRate;

    private void checkRate(){
    	heartRate = (int)(Math.random()*200+80);
    }
    
    public void run(){
    	while(true){
    		checkRate();
    		try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
    public static int getRate(){
    	return heartRate;
    }
}