package avengers;

import java.util.*;

public class Diarylist {
    public Diarylist() {
    }

    public void addDiary(String diaryID) {
    	
    }

    public String listDiary() {
        return "";
    }

    public String deleteDairy(String diaryID) {
        return "";
    }

    public void modifyDiary() {

    }

}