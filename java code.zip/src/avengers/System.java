package avengers;

import java.util.*;
import avengers.watch;
import avengers.camera;
import avengers.phone;

public class System extends Thread{
    public System() {
    }
    private String video;
    private int heartRate;
    private String GPS;
    private String Date;
    private String picture;
    private String DiaryID;
    
    public void run(){
    	while(true){
    		try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    		heartRate=watch.getRate();
    		
    		if(heartRate>130){
        		camera.storeVideo();
        		camera.takePicture();
        		phone.storeGPS();
    			getData();
    			makeDiary();
    		}
    	}
    }
    private void getData(){
    	Date date = new Date();
		Date = date.toString();
    	video = camera.getVideo();
    	picture = camera.getPicture();
    	GPS = phone.getGPS();
    }
    public void makeDiary() {
    	
    }
}