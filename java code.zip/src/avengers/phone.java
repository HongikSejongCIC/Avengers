package avengers;

import java.util.*;
import avengers.watch;
public class phone extends Thread{
    public phone() {}
    public String GPS;
    public int heartRate;

    static void storeGPS(){
    	
    }
    
    public static String getGPS(){
        return "";
    }

    public String getDate() {
        return "";
    }

}