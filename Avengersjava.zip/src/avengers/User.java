package avengers;

import java.util.*;

public class User {
    public User() {
    }

    private String name;
    private int age;
    private String male;
    private String phone;
    private String SNSaccount;

    public void UserMakeDiary() {
    	
    }

}