package avengers;

import java.util.*;
import java.io.*;

public class camera extends Thread{

    public camera() {
    	File Dir = new File("./video");
    }

    public static String video;
    public int heartRate;
    public String picture;
    private long time;
    static Date name = null;
    public void run(){
    	while(true){
    		
    		try {
				storeVideo();
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    }
    static void storeVideo() {
    	name = new Date();
		video = name.toString();
    	File file = new File(video+".wmv");
    }
    private static void removeVideo() {

    }

    public static String getVideo() {
        return "";
    }

    static void takePicture() {

    }

    public static String getPicture() {
        return "";
    }
}