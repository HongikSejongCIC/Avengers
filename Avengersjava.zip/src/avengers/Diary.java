package avengers;

import java.util.*;

public class Diary {
    public Diary() {
    }

    public String diaryID;
    public int heartRate;
    public String GPS;
    public String video;
    public String picture;
    public String Date;

    public String makeID() {

        return "";
    }

}